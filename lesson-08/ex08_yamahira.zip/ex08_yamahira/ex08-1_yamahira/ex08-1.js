var link = document.getElementById("link1").textContent
// var linkname = link.textContent
console.log(link)

var todo = document.getElementById("todo").firstElementChild.textContent
console.log(todo)

var doExam = document.querySelector(".list2").children[1].textContent
console.log(doExam)